Place any javascript files to load as AMD modules here in subdirectories

Note:

1) The subirectory name will be the module name. For example, placing javascript files in a
subdirectory named "Test" will load the module as "Test"

2) If you include a main.js in the subdirectory, it will get loaded automatically and can 
execute or load other code as needed.

File issues at https://github.com/CustomerFX/FX.CustomLoader.Module/issues

-- 
Developed by Customer FX Corporation
http://customerfx.com

Copyright 2016 Customer FX - GNU License 
https://raw.githubusercontent.com/CustomerFX/FX.CustomLoader.Module/master/LICENSE.txt
