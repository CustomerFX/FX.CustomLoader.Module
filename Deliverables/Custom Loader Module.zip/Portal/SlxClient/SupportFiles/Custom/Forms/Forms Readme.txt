Place text files here with any name and a .json extension, for example MyForm.json. You may use subdirectories 
to organize if needed or place in the root of this folder.

The contents of the file should be json with the folloinwg properties. 

{
    "ID": "mySmartPart",
    "SmartPart": "~/SmartParts/Account/MySmartPart.ascx",
    "Workspace": "DialogWorkspace",
    "Title": "Title",  <- optional
    "ShowInMode": "", <- optional 
    "EntityTypes": ["Account", "Contact"]  <- optional, omit to add form on all pages
}


File issues at https://github.com/CustomerFX/FX.CustomLoader.Module/issues

-- 
Developed by Customer FX Corporation
http://customerfx.com

Copyright Customer FX - GNU License 
https://raw.githubusercontent.com/CustomerFX/FX.CustomLoader.Module/master/LICENSE.txt
