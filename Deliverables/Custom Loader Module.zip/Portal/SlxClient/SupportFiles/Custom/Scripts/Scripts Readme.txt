Place any javascript files here. You may use subdirectories to organize if needed 
or place in the root of this folder.

File issues at https://github.com/CustomerFX/FX.CustomLoader.Module/issues

-- 
Developed by Customer FX Corporation
http://customerfx.com

Copyright 2016 Customer FX - GNU License 
https://raw.githubusercontent.com/CustomerFX/FX.CustomLoader.Module/master/LICENSE.txt
